/**
 * 共享的JS
 */
function navTo(url)
{
	location.href=url;
}

